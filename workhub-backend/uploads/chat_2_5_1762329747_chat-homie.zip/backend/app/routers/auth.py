from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from ..db import get_db
from .. import models, schemas
from ..utils.security import hash_password, verify_password, create_tokens

router = APIRouter(prefix="/auth", tags=["auth"])

@router.post("/signup", response_model=schemas.UserOut)
def signup(payload: schemas.UserCreate, db: Session = Depends(get_db)):
    if db.query(models.User).filter(models.User.email==payload.email).first():
        raise HTTPException(status_code=400, detail="Email already registered")
    u = models.User(email=payload.email, password_hash=hash_password(payload.password), display_name=payload.display_name)
    db.add(u); db.commit(); db.refresh(u)
    return schemas.UserOut.model_validate(u.__dict__)

@router.post("/login", response_model=schemas.TokenPair)
def login(payload: schemas.LoginIn, db: Session = Depends(get_db)):
    u = db.query(models.User).filter(models.User.email==payload.email).first()
    if not u or not verify_password(payload.password, u.password_hash):
        raise HTTPException(status_code=401, detail="Invalid credentials")
    at, rt = create_tokens(str(u.id))
    return {"access_token": at, "refresh_token": rt, "token_type": "bearer"}
