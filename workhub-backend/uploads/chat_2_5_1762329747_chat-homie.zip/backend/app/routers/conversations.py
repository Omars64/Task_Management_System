from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from sqlalchemy import select, desc
from ..db import get_db
from .. import models, schemas
from ..deps import get_current_user

router = APIRouter(prefix="/conversations", tags=["conversations"])

@router.post("", response_model=schemas.ConversationOut)
def create_conv(payload: schemas.ConversationCreate, db: Session = Depends(get_db), user: models.User = Depends(get_current_user)):
    if payload.type == "direct":
        # Direct: ensure exactly one other member
        if not payload.member_ids or len(payload.member_ids)!=1:
            raise HTTPException(status_code=400, detail="Direct chat requires exactly one member")
        # create or reuse by convention (simplified: always create)
    c = models.Conversation(type=models.ConversationType(payload.type), title=payload.title, created_by=user.id)
    db.add(c); db.flush()
    db.add(models.ConversationMember(conversation_id=c.id, user_id=user.id, role="admin" if payload.type=="group" else "member"))
    members = payload.member_ids or []
    for mid in members:
        if mid == user.id: 
            continue
        db.add(models.ConversationMember(conversation_id=c.id, user_id=mid, role="member"))
    db.commit(); db.refresh(c)
    return schemas.ConversationOut.model_validate(c.__dict__)

@router.get("", response_model=list[schemas.ConversationOut])
def list_convs(db: Session = Depends(get_db), user: models.User = Depends(get_current_user)):
    rows = db.execute(select(models.Conversation).join(models.ConversationMember, models.Conversation.id==models.ConversationMember.conversation_id).where(models.ConversationMember.user_id==user.id).order_by(desc(models.Conversation.created_at))).scalars().all()
    return [schemas.ConversationOut.model_validate(r.__dict__) for r in rows]
