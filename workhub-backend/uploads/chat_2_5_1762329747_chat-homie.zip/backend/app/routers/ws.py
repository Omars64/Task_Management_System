from fastapi import APIRouter, WebSocket, WebSocketDisconnect, Depends
from typing import Dict, Set
from sqlalchemy.orm import Session
from sqlalchemy import select
from ..db import get_db
from ..models import ConversationMember, Message, MessageType
from ..utils.security import verify_token

router = APIRouter()

class Hub:
    def __init__(self):
        self.rooms: Dict[int, Set[WebSocket]] = {}

    async def join(self, cid: int, ws: WebSocket):
        await ws.accept()
        self.rooms.setdefault(cid, set()).add(ws)

    def leave(self, cid: int, ws: WebSocket):
        self.rooms.get(cid, set()).discard(ws)

    async def broadcast(self, cid: int, data: dict):
        dead = []
        for ws in list(self.rooms.get(cid, set())):
            try:
                await ws.send_json(data)
            except Exception:
                dead.append(ws)
        for d in dead:
            self.rooms[cid].discard(d)

hub = Hub()

@router.websocket("/ws")
async def ws_endpoint(ws: WebSocket, token: str, cid: int, db: Session = Depends(get_db)):
    # token must be access token; verify membership
    uid = int(verify_token(token))
    member = db.execute(select(ConversationMember).where(ConversationMember.conversation_id==cid, ConversationMember.user_id==uid)).first()
    if not member:
        await ws.close(code=1008)
        return
    await hub.join(cid, ws)
    try:
        while True:
            data = await ws.receive_json()
            # expected: {"type":"text"|"image"|"video", "body":..., "attachment_url":...}
            msg = Message(conversation_id=cid, sender_id=uid, type=MessageType(data.get("type","text")), body=data.get("body"), attachment_url=data.get("attachment_url"))
            db.add(msg); db.commit(); db.refresh(msg)
            await hub.broadcast(cid, {"event":"message.new","message":{
                "id": msg.id, "conversation_id": cid, "sender_id": uid, "type": msg.type.value,
                "body": msg.body, "attachment_url": msg.attachment_url, "created_at": msg.created_at.isoformat()
            }})
    except WebSocketDisconnect:
        hub.leave(cid, ws)
