from fastapi import APIRouter, Depends, UploadFile, File, HTTPException
from sqlalchemy.orm import Session
from ..db import get_db
from .. import models, schemas
from ..deps import get_current_user
from ..settings import settings
import os, uuid, shutil

router = APIRouter(prefix="/me", tags=["me"])

@router.get("", response_model=schemas.UserOut)
def me(user: models.User = Depends(get_current_user)):
    return schemas.UserOut.model_validate(user.__dict__)

@router.put("", response_model=schemas.UserOut)
def update_me(payload: schemas.ProfileUpdate, db: Session = Depends(get_db), user: models.User = Depends(get_current_user)):
    if payload.display_name is not None:
        user.display_name = payload.display_name
    if payload.bio is not None:
        user.bio = payload.bio
    db.commit(); db.refresh(user)
    return schemas.UserOut.model_validate(user.__dict__)

@router.post("/avatar", response_model=schemas.UserOut)
def upload_avatar(file: UploadFile = File(...), db: Session = Depends(get_db), user: models.User = Depends(get_current_user)):
    if not file.content_type.startswith("image/"):
        raise HTTPException(status_code=400, detail="Invalid file type")
    ext = os.path.splitext(file.filename)[1].lower() or ".jpg"
    key = f"avatar_{user.id}_{uuid.uuid4().hex}{ext}"
    path = os.path.join(settings.MEDIA_DIR, key)
    with open(path,"wb") as f:
        shutil.copyfileobj(file.file, f)
    user.avatar_url = f"/media/{key}"
    db.commit(); db.refresh(user)
    return schemas.UserOut.model_validate(user.__dict__)
