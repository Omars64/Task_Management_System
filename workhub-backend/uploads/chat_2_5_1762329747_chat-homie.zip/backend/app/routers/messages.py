from fastapi import APIRouter, Depends, HTTPException, UploadFile, File
from sqlalchemy.orm import Session
from sqlalchemy import select, desc
from ..db import get_db
from .. import models, schemas
from ..deps import get_current_user
from ..settings import settings
import os, uuid, shutil

router = APIRouter(prefix="/conversations/{cid}/messages", tags=["messages"])

def member_check(db: Session, cid: int, uid: int):
    m = db.execute(select(models.ConversationMember).where(models.ConversationMember.conversation_id==cid, models.ConversationMember.user_id==uid)).first()
    if not m:
        raise HTTPException(status_code=403, detail="Not a member")

@router.get("", response_model=list[schemas.MessageOut])
def list_messages(cid: int, db: Session = Depends(get_db), user: models.User = Depends(get_current_user)):
    member_check(db, cid, user.id)
    msgs = db.execute(select(models.Message).where(models.Message.conversation_id==cid).order_by(desc(models.Message.created_at)).limit(50)).scalars().all()
    return [schemas.MessageOut.model_validate(x.__dict__) for x in reversed(msgs)]

@router.post("", response_model=schemas.MessageOut)
def send_message(cid: int, payload: schemas.MessageCreate, db: Session = Depends(get_db), user: models.User = Depends(get_current_user)):
    member_check(db, cid, user.id)
    if payload.type == "text" and not payload.body:
        raise HTTPException(status_code=400, detail="Text message requires body")
    msg = models.Message(conversation_id=cid, sender_id=user.id, type=models.MessageType(payload.type), body=payload.body, attachment_url=payload.attachment_url)
    db.add(msg); db.commit(); db.refresh(msg)
    return schemas.MessageOut.model_validate(msg.__dict__)

@router.post("/upload")
def upload_media(cid: int, file: UploadFile = File(...), db: Session = Depends(get_db), user: models.User = Depends(get_current_user)):
    member_check(db, cid, user.id)
    ct = file.content_type or ""
    allowed = set(settings.ALLOWED_IMAGE_TYPES.split(",")) | set(settings.ALLOWED_VIDEO_TYPES.split(","))
    if ct not in allowed:
        raise HTTPException(status_code=400, detail=f"Unsupported type {ct}")
    ext = os.path.splitext(file.filename)[1].lower() or (".jpg" if ct.startswith("image/") else ".mp4")
    key = f"conv{cid}_{uuid.uuid4().hex}{ext}"
    path = os.path.join(settings.MEDIA_DIR, key)
    with open(path,"wb") as f:
        shutil.copyfileobj(file.file, f)
    return {"url": f"/media/{key}"}
