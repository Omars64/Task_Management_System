from pydantic import BaseModel, EmailStr, field_validator, constr
from typing import Optional, List, Literal
from datetime import datetime

DisplayName = constr(min_length=1, max_length=50)
Bio = constr(min_length=0, max_length=160)

class UserCreate(BaseModel):
    email: EmailStr
    password: str
    display_name: DisplayName

    @field_validator("password")
    def strong_pw(cls, v):
        if len(v) < 10:
            raise ValueError("Password must be at least 10 characters")
        classes = sum([any(c.islower() for c in v), any(c.isupper() for c in v), any(c.isdigit() for c in v), any(not c.isalnum() for c in v)])
        if classes < 3:
            raise ValueError("Password must contain at least 3 of: lower/upper/digit/symbol")
        if len(v) > 256:
            raise ValueError("Password too long")
        return v

class UserOut(BaseModel):
    id: int
    email: EmailStr
    display_name: str
    bio: Optional[str] = None
    avatar_url: Optional[str] = None
    created_at: datetime

class TokenPair(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "bearer"

class LoginIn(BaseModel):
    email: EmailStr
    password: str

class ProfileUpdate(BaseModel):
    display_name: Optional[DisplayName] = None
    bio: Optional[Bio] = None

class ConversationCreate(BaseModel):
    type: Literal["direct","group"]
    title: Optional[constr(min_length=1, max_length=80)] = None
    member_ids: Optional[List[int]] = None

class ConversationOut(BaseModel):
    id: int
    type: str
    title: Optional[str] = None
    avatar_url: Optional[str] = None
    created_by: int
    created_at: datetime

class MessageCreate(BaseModel):
    type: Literal["text","image","video"]
    body: Optional[constr(min_length=1, max_length=4000)] = None
    attachment_url: Optional[str] = None

class MessageOut(BaseModel):
    id: int
    conversation_id: int
    sender_id: int
    type: str
    body: Optional[str]
    attachment_url: Optional[str]
    created_at: datetime
