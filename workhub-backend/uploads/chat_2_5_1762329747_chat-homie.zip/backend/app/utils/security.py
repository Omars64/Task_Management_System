from jose import jwt, JWTError
from datetime import datetime, timedelta, timezone
from typing import Tuple
from argon2 import PasswordHasher
from fastapi import HTTPException, status
from .settings import settings

ph = PasswordHasher()

def hash_password(pw: str) -> str:
    return ph.hash(pw)

def verify_password(pw: str, hashed: str) -> bool:
    try:
        return ph.verify(hashed, pw)
    except Exception:
        return False

def create_tokens(sub: str) -> Tuple[str,str]:
    now = datetime.now(timezone.utc)
    access = jwt.encode(
        {"sub": sub, "exp": now + timedelta(minutes=settings.ACCESS_TOKEN_EXPIRES_MIN)},
        settings.JWT_SECRET, algorithm=settings.JWT_ALG
    )
    refresh = jwt.encode(
        {"sub": sub, "exp": now + timedelta(days=settings.REFRESH_TOKEN_EXPIRES_DAYS), "typ":"refresh"},
        settings.JWT_SECRET, algorithm=settings.JWT_ALG
    )
    return access, refresh

def verify_token(token: str, refresh: bool=False) -> str:
    try:
        data = jwt.decode(token, settings.JWT_SECRET, algorithms=[settings.JWT_ALG])
        if refresh and data.get("typ") != "refresh":
            raise HTTPException(status_code=401, detail="Invalid refresh token")
        return data["sub"]
    except JWTError:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid token")
