from pydantic_settings import BaseSettings
from typing import List

class Settings(BaseSettings):
    DATABASE_URL: str = "postgresql+psycopg2://chat:chat@db:5432/chat"
    JWT_SECRET: str = "change-me"
    JWT_ALG: str = "HS256"
    ACCESS_TOKEN_EXPIRES_MIN: int = 15
    REFRESH_TOKEN_EXPIRES_DAYS: int = 30
    MEDIA_DIR: str = "/app/media"
    ALLOWED_IMAGE_TYPES: str = "image/jpeg,image/png,image/webp"
    ALLOWED_VIDEO_TYPES: str = "video/mp4,video/quicktime"
    MAX_IMAGE_MB: int = 8
    MAX_VIDEO_MB: int = 32

    class Config:
        env_file = ".env"

settings = Settings()
