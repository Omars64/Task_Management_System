import React from "react";
import { NavigationContainer } from "@react-navigation/native";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { StatusBar } from "expo-status-bar";
import Login from "./screens/Login";
import Feed from "./screens/Feed";
import Chat from "./screens/Chat";
import Profile from "./screens/Profile";
import NewGroup from "./screens/NewGroup";

export type RootStackParamList = {
  Login: undefined;
  Feed: undefined;
  Chat: { id: number; title?: string };
  Profile: undefined;
  NewGroup: undefined;
};

const Stack = createNativeStackNavigator<RootStackParamList>();

export default function App() {
  return (
    <NavigationContainer>
      <StatusBar style="light" />
      <Stack.Navigator initialRouteName="Login" screenOptions={{ headerStyle: { backgroundColor: "#0e497e" }, headerTintColor: "#fff" }}>
        <Stack.Screen name="Login" component={Login} options={{ title: "Chat Homie" }} />
        <Stack.Screen name="Feed" component={Feed} options={{ title: "Chats" }} />
        <Stack.Screen name="Chat" component={Chat} options={({ route }) => ({ title: route.params?.title || "Chat" })} />
        <Stack.Screen name="Profile" component={Profile} />
        <Stack.Screen name="NewGroup" component={NewGroup} options={{ title: "New Group" }} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
