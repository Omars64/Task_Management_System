import React, { useEffect, useState } from "react";
import { View, Text, FlatList, Pressable, ActivityIndicator } from "react-native";
import api from "../api";
import AsyncStorage from "@react-native-async-storage/async-storage";

type Conversation = { id:number; type:string; title?:string; created_by:number; created_at:string };

export default function Feed({ navigation }: any) {
  const [convs,setConvs] = useState<Conversation[]>([]);
  const [loading,setLoading] = useState(true);

  useEffect(()=>{
    (async ()=>{
      const t = await AsyncStorage.getItem("token");
      if (!t) return navigation.replace("Login");
      try{
        const { data } = await api.get("/conversations");
        setConvs(data);
      } finally{
        setLoading(false);
      }
    })();
  },[]);

  if (loading) return <View style={{flex:1, justifyContent:"center", alignItems:"center"}}><ActivityIndicator/></View>;

  return (
    <View style={{flex:1, backgroundColor:"#0b1720"}}>
      <View style={{ flexDirection:"row", justifyContent:"space-between", padding:12 }}>
        <Pressable onPress={()=>navigation.navigate("Profile")}><Text style={{color:"#fff"}}>Profile</Text></Pressable>
        <Pressable onPress={()=>navigation.navigate("NewGroup")}><Text style={{color:"#fff"}}>New Group</Text></Pressable>
      </View>
      <FlatList
        data={convs}
        keyExtractor={(i)=>String(i.id)}
        renderItem={({item})=>(
          <Pressable onPress={()=>navigation.navigate("Chat",{ id:item.id, title:item.title || "Chat" })} style={{ padding:16, borderBottomColor:"#13202d", borderBottomWidth:1 }}>
            <Text style={{ color:"#fff", fontSize:16 }}>{item.title || "Direct chat"}</Text>
            <Text style={{ color:"#a7b4c2", fontSize:12 }}>{new Date(item.created_at).toLocaleString()}</Text>
          </Pressable>
        )}
      />
    </View>
  );
}
