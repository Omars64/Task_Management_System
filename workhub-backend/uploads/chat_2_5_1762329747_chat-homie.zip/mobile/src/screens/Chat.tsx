import React, { useEffect, useRef, useState } from "react";
import { View, TextInput, Pressable, FlatList, Text, Alert } from "react-native";
import { colors } from "../theme/colors";
import MessageBubble from "../components/MessageBubble";
import api from "../api";
import * as ImagePicker from "expo-image-picker";
import AsyncStorage from "@react-native-async-storage/async-storage";

type Msg = { id:number; sender_id:number; type:string; body?:string; attachment_url?:string; created_at:string };

export default function Chat({ route }: any) {
  const { id: cid } = route.params;
  const [msgs,setMsgs] = useState<Msg[]>([]);
  const [text,setText] = useState("");
  const wsRef = useRef<WebSocket|null>(null);
  const [uid,setUid] = useState<number|null>(null);

  useEffect(()=>{
    (async ()=>{
      const tok = await AsyncStorage.getItem("token");
      if (!tok) return;
      const me = await api.get("/me");
      setUid(me.data.id);
      const { data } = await api.get(`/conversations/${cid}/messages`);
      setMsgs(data);
      const url = new URL("/ws", api.defaults.baseURL);
      url.searchParams.set("token", tok);
      url.searchParams.set("cid", String(cid));
      const ws = new WebSocket(url.toString().replace("http","ws"));
      wsRef.current = ws;
      ws.onmessage = (ev)=>{
        const payload = JSON.parse(ev.data);
        if (payload.event === "message.new") {
          setMsgs((prev)=>[...prev, payload.message]);
        }
      };
      return () => ws.close();
    })();
  },[cid]);

  async function sendText() {
    if (!text.trim()) return;
    wsRef.current?.send(JSON.stringify({ type:"text", body:text.trim() }));
    setText("");
  }

  async function sendMedia() {
    const res = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ImagePicker.MediaTypeOptions.All, quality: 0.8 });
    if (res.canceled || !res.assets?.length) return;
    const asset = res.assets[0];
    const form = new FormData();
    // @ts-ignore
    form.append("file", { uri: asset.uri, name: asset.fileName || "upload", type: asset.mimeType || "application/octet-stream" });
    try {
      const { data } = await api.post(`/conversations/${cid}/messages/upload`, form, { headers: { "Content-Type":"multipart/form-data" } });
      wsRef.current?.send(JSON.stringify({ type: asset.type === "video" ? "video" : "image", attachment_url: data.url }));
    } catch (e:any) {
      Alert.alert("Upload error", e?.response?.data?.detail || e.message);
    }
  }

  return (
    <View style={{ flex:1, backgroundColor:"#0b1720" }}>
      <FlatList
        data={msgs}
        keyExtractor={(i)=>String(i.id)}
        renderItem={({item})=>(
          <MessageBubble mine={item.sender_id===uid} text={item.type==="text"?item.body:undefined} imageUri={item.type!=="text"?item.attachment_url:undefined} />
        )}
        contentContainerStyle={{ padding:12 }}
      />
      <View style={{ flexDirection:"row", padding:8, borderTopColor:"#13202d", borderTopWidth:1 }}>
        <Pressable onPress={sendMedia} style={{ backgroundColor:colors.primary, padding:10, borderRadius:10, marginRight:8 }}><Text style={{ color:"#fff" }}>+</Text></Pressable>
        <TextInput value={text} onChangeText={setText} placeholder="Message" placeholderTextColor="#789" style={{ flex:1, backgroundColor:"#13202d", color:"#fff", borderRadius:10, paddingHorizontal:10 }}/>
        <Pressable onPress={sendText} style={{ backgroundColor:colors.primary, padding:10, borderRadius:10, marginLeft:8 }}><Text style={{ color:"#fff" }}>Send</Text></Pressable>
      </View>
    </View>
  );
}
