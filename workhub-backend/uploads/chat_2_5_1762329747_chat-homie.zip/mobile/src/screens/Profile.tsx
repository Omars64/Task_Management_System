import React, { useEffect, useState } from "react";
import { View, Text, TextInput, Pressable, Alert } from "react-native";
import api from "../api";

export default function Profile() {
  const [me,setMe] = useState<any>(null);
  const [name,setName] = useState("");
  const [bio,setBio] = useState("");

  useEffect(()=>{
    (async ()=>{
      const { data } = await api.get("/me");
      setMe(data); setName(data.display_name||""); setBio(data.bio||"");
    })();
  },[]);

  async function save() {
    try{
      const { data } = await api.put("/me", { display_name: name, bio });
      setMe(data);
      Alert.alert("Saved","Profile updated");
    }catch(e:any){ Alert.alert("Error", e?.response?.data?.detail || e.message); }
  }

  return (
    <View style={{ flex:1, backgroundColor:"#0b1720", padding:16 }}>
      <Text style={{ color:"#fff", fontSize:22, marginBottom:10 }}>Profile</Text>
      <Text style={{ color:"#a7b4c2" }}>Email</Text>
      <Text style={{ color:"#fff", marginBottom:10 }}>{me?.email}</Text>
      <TextInput value={name} onChangeText={setName} placeholder="Display name" placeholderTextColor="#789" style={{ color:"#fff", borderColor:"#0e497e", borderWidth:1, borderRadius:10, padding:10, marginBottom:10 }} />
      <TextInput value={bio} onChangeText={setBio} placeholder="Bio" placeholderTextColor="#789" style={{ color:"#fff", borderColor:"#0e497e", borderWidth:1, borderRadius:10, padding:10, marginBottom:10 }} />
      <Pressable onPress={save} style={{ backgroundColor:"#0e497e", padding:12, borderRadius:10 }}>
        <Text style={{ color:"#fff", textAlign:"center" }}>Save</Text>
      </Pressable>
    </View>
  );
}
