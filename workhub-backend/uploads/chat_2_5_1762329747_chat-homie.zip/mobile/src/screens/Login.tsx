import React, { useState } from "react";
import { View, Text, TextInput, Pressable, Alert } from "react-native";
import api, { setToken } from "../api";
import AsyncStorage from "@react-native-async-storage/async-storage";

export default function Login({ navigation }: any) {
  const [email,setEmail] = useState("");
  const [password,setPassword] = useState("");
  const [name,setName] = useState("");
  const [mode,setMode] = useState<"login"|"signup">("login");

  async function handleAuth() {
    try {
      if (mode === "signup") {
        await api.post("/auth/signup", { email, password, display_name: name });
      }
      const { data } = await api.post("/auth/login", { email, password });
      await AsyncStorage.setItem("token", data.access_token);
      setToken(data.access_token);
      navigation.replace("Feed");
    } catch (e: any) {
      Alert.alert("Auth error", e?.response?.data?.detail || e.message);
    }
  }

  return (
    <View style={{ flex:1, backgroundColor: "#0b1720", padding: 16, justifyContent:"center"}}>
      <Text style={{ color:"#fff", fontSize:28, textAlign:"center", marginBottom:20 }}>Chat Homie</Text>
      {mode==="signup" && (
        <TextInput placeholder="Display name" placeholderTextColor="#789" value={name} onChangeText={setName} style={{ color:"#fff", borderColor:"#0e497e", borderWidth:1, borderRadius:10, padding:10, marginBottom:10 }} />
      )}
      <TextInput placeholder="Email" keyboardType="email-address" autoCapitalize="none" placeholderTextColor="#789" value={email} onChangeText={setEmail} style={{ color:"#fff", borderColor:"#0e497e", borderWidth:1, borderRadius:10, padding:10, marginBottom:10 }} />
      <TextInput placeholder="Password" secureTextEntry placeholderTextColor="#789" value={password} onChangeText={setPassword} style={{ color:"#fff", borderColor:"#0e497e", borderWidth:1, borderRadius:10, padding:10, marginBottom:10 }} />
      <Pressable onPress={handleAuth} style={{ backgroundColor:"#0e497e", padding:12, borderRadius:10, marginTop:10 }}>
        <Text style={{ color:"#fff", textAlign:"center" }}>{mode==="login" ? "Log in" : "Sign up"}</Text>
      </Pressable>
      <Pressable onPress={()=>setMode(mode==="login"?"signup":"login")} style={{ padding:12 }}>
        <Text style={{ color:"#a7b4c2", textAlign:"center" }}>{mode==="login"?"Need an account? Sign up":"Have an account? Log in"}</Text>
      </Pressable>
    </View>
  );
}
