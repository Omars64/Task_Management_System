import React, { useState } from "react";
import { View, Text, TextInput, Pressable, Alert } from "react-native";
import api from "../api";

export default function NewGroup({ navigation }: any) {
  const [title,setTitle] = useState("");

  async function create() {
    if (!title.trim()) return;
    try{
      const { data } = await api.post("/conversations", { type:"group", title });
      navigation.replace("Chat", { id: data.id, title: data.title });
    }catch(e:any){
      Alert.alert("Error", e?.response?.data?.detail || e.message);
    }
  }

  return (
    <View style={{ flex:1, backgroundColor:"#0b1720", padding:16 }}>
      <Text style={{ color:"#fff", fontSize:22, marginBottom:10 }}>Create Group</Text>
      <TextInput value={title} onChangeText={setTitle} placeholder="Group name" placeholderTextColor="#789" style={{ color:"#fff", borderColor:"#0e497e", borderWidth:1, borderRadius:10, padding:10, marginBottom:10 }} />
      <Pressable onPress={create} style={{ backgroundColor:"#0e497e", padding:12, borderRadius:10 }}>
        <Text style={{ color:"#fff", textAlign:"center" }}>Create</Text>
      </Pressable>
    </View>
  );
}
