import React from "react";
import { View, Text, Image } from "react-native";
import { colors } from "../theme/colors";

export default function MessageBubble({ mine, text, imageUri }: { mine:boolean; text?:string; imageUri?:string }) {
  return (
    <View style={{ alignSelf: mine ? "flex-end" : "flex-start", backgroundColor: mine ? colors.bubbleMine : colors.bubbleTheirs, padding: 10, borderRadius: 14, marginVertical: 4, maxWidth: "80%" }}>
      {imageUri ? <Image source={{uri:imageUri}} style={{width:220,height:220,borderRadius:10,marginBottom:6}} /> : null}
      {!!text && <Text style={{color: colors.text}}>{text}</Text>}
    </View>
  );
}
