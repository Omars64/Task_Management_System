export const colors = {
  primary: "#0e497e",
  bg: "#0b1720",
  bubbleMine: "#0e497e",
  bubbleTheirs: "#15202b",
  text: "#ffffff",
  subtext: "#a7b4c2",
};
