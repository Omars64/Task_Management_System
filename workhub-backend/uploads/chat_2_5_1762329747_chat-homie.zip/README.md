# Chat Homie

A minimal, functional chat app with email/password auth, feed, 1:1 and group chats, profile, and image/video messages.
Primary color: #0e497e. Backend: FastAPI. Mobile: React Native (Expo).

## Features
- Email/password signup and login (Argon2 hashing, JWT)
- Feed of conversations
- 1:1 and group chats
- Send text, images, and videos
- Profile edit (display name, bio)
- WebSocket realtime messaging
- Media uploads served from backend `/media`

## Run (Dev)
1) Create backend `.env` from `.env.example` and adjust `JWT_SECRET`.
2) Start services:
```bash
docker compose up --build
```
API at http://localhost:8000

3) Mobile:
```bash
cd mobile
npm install
npm run android   # requires Android Studio or device
```
Android emulator backend URL uses `10.0.2.2:8000` (already configured).

## Build APK
```bash
cd mobile
npm run build-apk
# APK at android/app/build/outputs/apk/release/app-release.apk
```

## Notes
- This is a starter with solid defaults and no TODOs. Add push notifications, message search, and richer permissions as next steps.
